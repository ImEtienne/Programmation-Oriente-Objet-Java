package TP5_Java.Exo3;
import fr.lacl.cpo.Drawing ;
import TP5_Java.Point;
/**
 * Décrivez votre classe Forme ici.
 *
 * @author (votre nom)
 * @version (un numéro de version ou une date)
 */
public class Forme
{
    private Point [] p;
    public Forme(Point [] p){
        this.p = new Point [p.length];
    }
}
