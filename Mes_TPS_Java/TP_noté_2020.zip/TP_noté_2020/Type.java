package TP_noté_2020;
/**
 * Enumeration Type - écrire ici la description de l'énumération
 *
 * @author (votre nom)
 * @version (numéro de version ou date)
 */
public enum Type
{
    ALIMENTAIRE, MAISON, VETEMENT
}
