package TP_noté_2020;
/**
 * Décrivez votre classe CommandeException ici.
 *
 * @author (votre nom)
 * @version (un numéro de version ou une date)
 */
public class CommandeException extends Exception
{
    public CommandeException(String message){
        super(message);
    }
}
