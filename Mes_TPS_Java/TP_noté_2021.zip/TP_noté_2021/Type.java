package TP_noté_2021;


/**
 * Enumeration Type - écrire ici la description de l'énumération
 *
 * @author (votre nom)
 * @version (numéro de version ou date)
 */
public enum Type
{
    LIVRE, MAGAZINE, REVUE;
}
