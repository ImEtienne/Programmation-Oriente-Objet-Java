package TP_noté_2021;


/**
 * Enumeration TypeAuteur - écrire ici la description de l'énumération
 *
 * @author (votre nom)
 * @version (numéro de version ou date)
 */
public enum TypeAuteur
{
    ROMANTIER, BIOGRAPHES, POETE;
}
