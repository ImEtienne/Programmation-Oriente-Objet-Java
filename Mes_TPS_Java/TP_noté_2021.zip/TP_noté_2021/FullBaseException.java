package TP_noté_2021;


/**
 * Décrivez votre classe FullBaseException ici.
 *
 * @author (votre nom)
 * @version (un numéro de version ou une date)
 */
public class FullBaseException extends Exception
{
    public FullBaseException(String message){
        super(message);
    }
}
